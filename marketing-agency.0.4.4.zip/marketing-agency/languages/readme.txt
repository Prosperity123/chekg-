Place your theme language files in this directory.

Please visit the following links to learn more about translating WordPress themes:

http://codex.wordpress.org/Translating_WordPress
http://codex.wordpress.org/Function_Reference/load_theme_textdomain
